// Java Script for Blog page

// ID defined
const bookReviewContainer = document.querySelector('#bookReview');

// Articles defined
